﻿namespace BankAccounts.Customers
{
    using System;

    public enum Customers
    {
        Individual,
        Company
    }
}
