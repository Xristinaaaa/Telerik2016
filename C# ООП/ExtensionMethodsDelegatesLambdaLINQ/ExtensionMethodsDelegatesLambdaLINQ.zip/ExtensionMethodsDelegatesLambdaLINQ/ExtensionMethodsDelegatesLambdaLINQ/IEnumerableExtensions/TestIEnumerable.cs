﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodsDelegatesLambdaLINQ.IEnumerableExtensions
{
    public class TestIEnumerable
    {
        static public void Testing()
        {
            var list = new List<int>() { 2, 3, 45, 12, 6, 3, 24, 6 };

            
        }
    }
}