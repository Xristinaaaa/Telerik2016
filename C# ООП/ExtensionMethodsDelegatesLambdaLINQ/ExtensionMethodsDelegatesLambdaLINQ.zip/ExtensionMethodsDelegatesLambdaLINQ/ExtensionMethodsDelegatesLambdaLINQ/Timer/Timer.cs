﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethodsDelegatesLambdaLINQ
{
    class Timer
    {
        public void InvokingMethods()
        {
            //var timer = new System.Threading.Timer((e) =>
            //{
            //    Models.StringBuilderExtensions.Substring();
            //}, null, 0, TimeSpan.FromSeconds(10).TotalMilliseconds);
        }
    }
}
