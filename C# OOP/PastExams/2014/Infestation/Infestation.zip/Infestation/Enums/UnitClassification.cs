﻿namespace Infestation.Enums
{
    public enum UnitClassification
    {
        Biological,
        Mechanical,
        Psionic,
        Unknown
    }
}
