﻿namespace Infestation.Enums
{
    public enum InteractionType
    {
        Attack,
        Infest,
    }
}
