﻿namespace Infestation.Models.Supplements
{
    using System;
    public class AggressionCatalyst : Catalyst
    {
        public AggressionCatalyst()
            : base(0, 0, 3)
        {

        }
    }
}
