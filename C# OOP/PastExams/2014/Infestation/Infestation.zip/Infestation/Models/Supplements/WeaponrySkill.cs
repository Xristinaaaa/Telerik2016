﻿namespace Infestation.Models.Supplements
{
    using Infestation.SupplementSpec;
    using System;

    public class WeaponrySkill : Supplement
    {
        public WeaponrySkill()
            : base(0, 0, 0)
        {
        }
    }
}
