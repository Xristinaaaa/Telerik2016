﻿namespace Infestation.Models.Supplements
{
    using System;
    public class PowerCatalyst : Catalyst
    {
        public PowerCatalyst() 
            : base(3, 0, 0)
        {
        }
    }
}
