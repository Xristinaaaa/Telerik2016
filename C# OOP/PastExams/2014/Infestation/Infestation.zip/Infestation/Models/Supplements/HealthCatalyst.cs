﻿namespace Infestation.Models.Supplements
{
    using System;
    public class HealthCatalyst : Catalyst
    {
        public HealthCatalyst()
            : base(0, 3, 0)
        {
        }
    }
}
