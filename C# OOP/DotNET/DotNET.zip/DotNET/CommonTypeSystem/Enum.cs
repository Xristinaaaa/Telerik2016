﻿namespace CommonTypeSystem
{
    using System;
    public enum Universities
    {
        SofiaUni, 
        UNWE,
        TechnicalUni
    }
    public enum Specialties
    {
        Architecture,
        Programming, 
        Economics
    } 
    public enum Faculties
    {
        Mathematics,
        Chemistry,
        Informatics
    }
}
