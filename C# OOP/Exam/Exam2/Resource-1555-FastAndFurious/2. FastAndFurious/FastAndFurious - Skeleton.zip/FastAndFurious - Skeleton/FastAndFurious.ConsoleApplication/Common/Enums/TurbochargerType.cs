﻿namespace FastAndFurious.ConsoleApplication.Common.Enums
{
    public enum Template
    {
        NotSet=0,
        SequentialTurbo,
        TwinTurbo
    }
}
