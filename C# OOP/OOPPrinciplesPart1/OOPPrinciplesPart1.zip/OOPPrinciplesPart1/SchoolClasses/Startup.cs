﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SchoolClasses.School.Classes;
using SchoolClasses.School.Disciplines;
using SchoolClasses.School.People;

namespace SchoolClasses
{
    class Startup
    {
        static void Main(string[] args)
        {
            
        }
    }
}
