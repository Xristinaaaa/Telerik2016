﻿namespace StudentsAndWorkers.List
{
    using System;
    public class Lists
    {

    }
}
