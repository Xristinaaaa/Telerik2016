﻿namespace AnimalHierarchy.Animals.Animals
{
    using System;

    public enum Sex
    {
        female,
        male
    }
}
