﻿namespace Santase.Logic.Players
{
    public enum PlayerActionType
    {
        PlayCard = 1,
        ChangeTrump = 2,
        CloseGame = 3
    }
}
