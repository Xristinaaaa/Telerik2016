﻿using System;

namespace _1.StudentsAndCourses
{
    class Startup
    {
        static void Main(string[] args)
        {
            var school = new School();
        }
    }
}
